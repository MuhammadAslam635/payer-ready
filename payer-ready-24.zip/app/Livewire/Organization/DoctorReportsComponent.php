<?php

namespace App\Livewire\Organization;

use App\Models\DoctorLicense;
use App\Models\Insurance;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Doctor Reports')]
#[Layout('layouts.dashboard')]
class DoctorReportsComponent extends Component
{
    public $startDate = null;
    public $endDate = null;

    public array $items = [];

    public function updated($property): void
    {
        if (in_array($property, ['startDate', 'endDate'])) {
            $this->loadData();
        }
    }

    public function mount(): void
    {
        $this->loadData();
    }

    private function loadData(): void
    {
        $adminId = Auth::id();
        $doctorIds = User::query()
            ->where('org_id', $adminId)
            ->where('user_type', \App\Enums\UserType::DOCTOR)
            ->pluck('id');

        // Get organization name
        $organization = User::find($adminId);
        $organizationName = $organization->name ?? 'Organization';

        $licensesQuery = DoctorLicense::query()
            ->whereIn('user_id', $doctorIds)
            ->with(['licenseType', 'state']);

        $insurancesQuery = Insurance::query()
            ->whereIn('user_id', $doctorIds);

        if ($this->startDate) {
            $licensesQuery->whereDate('created_at', '>=', $this->startDate);
            $insurancesQuery->whereDate('created_at', '>=', $this->startDate);
        }
        if ($this->endDate) {
            $licensesQuery->whereDate('created_at', '<=', $this->endDate);
            $insurancesQuery->whereDate('created_at', '<=', $this->endDate);
        }

        $licenses = $licensesQuery->get()->map(function ($license) use ($organizationName) {
            return [
                'category' => 'License',
                'about' => trim(($license->licenseType->name ?? 'License') . ' ' . (isset($license->state) ? '(' . ($license->state->code ?? $license->state->name) . ')' : '')),
                'organization' => $organizationName,
                'group_npi' => $license->license_number ?? null,
                'created_at' => $license->created_at,
            ];
        });

        $insurances = $insurancesQuery->get()->map(function ($ins) use ($organizationName) {
            return [
                'category' => 'Insurance',
                'about' => trim(($ins->carrier ?? 'Insurance') . ' - Policy ' . ($ins->policy_number ?? '—')),
                'organization' => $organizationName,
                'group_npi' => $ins->policy_number ?? null,
                'created_at' => $ins->created_at,
            ];
        });

        $this->items = $licenses
            ->concat($insurances)
            ->sortBy(function ($item) {
                return is_null($item['created_at']) ? PHP_INT_MAX : $item['created_at']->timestamp;
            })
            ->values()
            ->all();
    }

    public function render()
    {
        return view('livewire.organization.doctor-reports-component');
    }
}


