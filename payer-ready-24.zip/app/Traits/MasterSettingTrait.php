<?php

namespace App\Traits;

trait MasterSettingTrait
{
    //
}
