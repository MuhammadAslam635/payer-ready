<?php

namespace App\Traits\Admin;

trait QuestionTrait
{
    //
}
