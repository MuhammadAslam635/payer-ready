<?php

namespace App\Traits\Admin;

trait CertificateTrait
{
    //
}
