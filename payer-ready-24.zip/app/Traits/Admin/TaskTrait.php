<?php

namespace App\Traits\Admin;

trait TaskTrait
{
    //
}
