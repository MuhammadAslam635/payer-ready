<?php

namespace App\Pipelines;

class TransactionFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
