<?php

namespace App\Pipelines;

class DocumentFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
