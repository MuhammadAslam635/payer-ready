<?php

namespace App\Pipelines;

class OrganizationFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
