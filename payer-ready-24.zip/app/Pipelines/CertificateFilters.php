<?php

namespace App\Pipelines;

class CertificateFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
