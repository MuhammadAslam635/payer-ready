<?php

namespace App\Pipelines;

class TaskFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
