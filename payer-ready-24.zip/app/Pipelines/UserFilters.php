<?php

namespace App\Pipelines;

class UserFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
