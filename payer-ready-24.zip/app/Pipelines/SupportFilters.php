<?php

namespace App\Pipelines;

class SupportFilters
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
