<x-guest-layout>
    @livewire('organization-registration')
</x-guest-layout>
