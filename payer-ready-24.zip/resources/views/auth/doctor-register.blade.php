<x-guest-layout>
    @livewire('registration', ['userType' => 'doctor'])
</x-guest-layout>
