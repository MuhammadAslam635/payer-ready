<div 
    {{ $attributes->class('flex gap-1.5 dark:bg-neutral-800 cursor-pointer px-1.5 dark:text-neutral-400 items-center bg-neutral-50 text-neutral-600 data-[slot=input-suffix]:rounded-r-box data-[slot=input-prefix]:rounded-l-box') }}
>
   {{ $slot }}
</div>