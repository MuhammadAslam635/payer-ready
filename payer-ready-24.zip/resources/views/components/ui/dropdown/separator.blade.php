<div {{ $attributes->merge(['class' => 'my-1 -mx-(--dropdown-padding) h-px grid-cols-subgrid col-span-full bg-gray-800/5 dark:bg-white/10']) }}></div>
