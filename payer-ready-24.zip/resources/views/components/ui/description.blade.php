<div {{ $attributes->class('text-sm text-neutral-500 dark:text-neutral-400') }} data-slot="description">
    {{ $slot }}
</div>