<div {{ $attributes->merge(['class' => 'cursor-pointer py-2 font-semibold']) }}>
    {{ $slot }}
</div>
