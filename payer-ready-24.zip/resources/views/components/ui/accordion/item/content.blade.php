<div {{ $attributes->merge(['class' => 'p-2 border-t']) }}>
    {{ $slot }}
</div>
