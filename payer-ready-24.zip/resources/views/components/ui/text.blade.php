<div 
    {{ $attributes->class('text-neutral-950  [:where(&)]:text-sm [:where(&)]:text-start dark:text-neutral-50') }} 
    data-slot="text"
>
    {{ $slot }}
</div>